<?php
/**
 * Orders Page
 *
 * @package WooCommerce_Point_Of_Sale/Classes/Admin
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'WC_POS_Admin_Orders_Page', false ) ) {
	return new WC_POS_Admin_Orders_Page();
}

/**
 * WC_POS_Admin_Orders_Page.
 */
class WC_POS_Admin_Orders_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'woocommerce_admin_order_buyer_name', [ $this, 'update_order_buyer_name' ], 10, 2 );

		// CPT orders.
		add_action( 'manage_shop_order_posts_custom_column', [ $this, 'display_order_type_column_cpt' ], 10, 2 );
		add_filter( 'manage_edit-shop_order_columns', [ $this, 'add_order_type_column' ], 9999 );

		// HPOS orders.
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'display_order_type_column_hpos' ], 10, 2 );
		add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_order_type_column' ], 9999 );

		add_action( 'restrict_manage_posts', [ $this, 'restrict_manage_orders' ] );
		add_action( 'woocommerce_order_list_table_restrict_manage_orders', [ $this, 'restrict_manage_orders' ] );
		add_action( 'add_meta_boxes', [ $this, 'add_order_metabox' ] );
	}

	/**
	 * Change guest order buyer's name.
	 *
	 * @param string   $buyer Buyer name.
	 * @param WC_Order $order Order object.
	 *
	 * @return string Updated buyer's name.
	 */
	public function update_order_buyer_name( $buyer, $order ) {
		if ( 'pos' === $order->get_data()['created_via'] && ! $buyer ) {
			$buyer = __( 'Walk-in Customer', 'woocommerce-point-of-sale' );
		}

		return $buyer;
	}

	/**
	 * Displays order type in orders table.
	 *
	 * @param string $created_via Order's created via value.
	 * @return void
	 */
private function echo_order_type( $created_via ) {
    if ( 'admin' === $created_via ) {
        $order_type = '<span class="order-type-admin tips" data-tip="Manual Order Icon">Manual</span>';
    } elseif ( 'rest-api' === $created_via ) {
        $order_type = '<span class="order-type-rest-api tips" data-tip="API Order Icon">API</span>';
    } elseif ( 'subscription' === $created_via ) {
        $order_type = '<span class="order-type-subscription tips" data-tip="Subscription Order Icon">Subscription</span>';
    } elseif ( 'pos' === $created_via ) {
        $order_type = '<span class="order-type-pos tips" data-tip="POS Order Icon">POS</span>';
    } else {
        $order_type = '<span class="order-type-checkout tips" data-tip="Website Order Icon">Website</span>';
    }

    echo wp_kses_post( $order_type );
}


	/**
	 * Displays order type column for CPT.
	 *
	 * @param string $column
	 * @param int    $post_id
	 */
	public function display_order_type_column_cpt( $column, $post_id ) {
		if ( 'wc_pos_order_type' === $column ) {
			$order = wc_get_order( $post_id );

			if ( $order ) {
				$this->echo_order_type( $order->get_created_via() );
			}
		}
	}

	/**
	 * Displays order type column for HPOS.
	 *
	 * @param string   $column Column ID.
	 * @param WC_Order $order  The order object.
	 */
	public function display_order_type_column_hpos( $column, $order ) {
		if ( 'wc_pos_order_type' === $column ) {
			$this->echo_order_type( $order->get_created_via() );
		}
	}

	/**
	 * Adds an order type column to the orders listing table.
	 *
	 * @param array $columns
	 * @return array
	 */
	public function add_order_type_column( $columns ) {
		$new_columns = [];

		foreach ( $columns as $key => $value ) {
			if ( 'order_number' === $key ) {
				$new_columns['wc_pos_order_type'] = sprintf(
					'<span class="order-type tips" data-tip="%s">%s</span>',
					esc_attr__( 'Order Type', 'woocommerce-point-of-sale' ),
					esc_html__( 'Order Type', 'woocommerce-point-of-sale' )
				);

			}

			$new_columns[ $key ] = $value;
		}

		return $new_columns;
	}

	private function is_orders_page() {
		$screen         = get_current_screen();
		$screen_id      = $screen ? $screen->id : '';
		$allowed_screen = [ 'edit-shop_order' ];

		if ( class_exists( 'Automattic\WooCommerce\Utilities\OrderUtil' ) ) {
			array_push( $allowed_screen, Automattic\WooCommerce\Utilities\OrderUtil::get_order_admin_screen() );
		}

		if ( in_array( $screen_id, $allowed_screen, true ) ) {
			return true;
		}

		return false;
	}

	public function restrict_manage_orders() {
		if ( ! $this->is_orders_page() ) {
			return;
		}

		$req_type = isset( $_REQUEST['_created_via'] ) ? wc_clean( wp_unslash( $_REQUEST['_created_via'] ) ) : '';
		$req_reg  = isset( $_REQUEST['_register_id'] ) ? wc_clean( wp_unslash( $_REQUEST['_register_id'] ) ) : '';
		$req_out  = isset( $_REQUEST['_outlet_id'] ) ? wc_clean( wp_unslash( $_REQUEST['_outlet_id'] ) ) : '';
		?>
		<select name='_created_via' id='dropdown__created_via'>
			<option value=""><?php esc_attr_e( 'All types', 'woocommerce-point-of-sale' ); ?></option>
			<option value="online" <?php selected( $req_type, 'online', true ); ?> ><?php esc_html_e( 'Online', 'woocommerce-point-of-sale' ); ?></option>
			<option value="pos" <?php selected( $req_type, 'pos', true ); ?> ><?php esc_html_e( 'POS', 'woocommerce-point-of-sale' ); ?></option>
		</select>
		<?php
		$filters = get_option( 'wc_pos_order_filters', [ 'registers' ] );

		if ( ! $filters || ! is_array( $filters ) ) {
			return;
		}

		if ( in_array( 'registers', $filters, true ) ) {
			$registers = get_posts(
				[
					'numberposts' => -1,
					'post_type'   => 'pos_register',
				]
			);

			if ( $registers ) {
				?>
		<select name='_register_id' id='_register_id'>
			<option value=""><?php esc_html_e( 'All registers', 'woocommerce-point-of-sale' ); ?></option>
				<?php
				foreach ( $registers as $register ) {
					echo '<option value="' . esc_attr( $register->ID ) . '" ' . selected( $req_reg, $register->ID, false ) . ' >' . esc_html( $register->post_title ) . '</option>';
				}
				?>
		</select>
				<?php
			}
		}
		if ( in_array( 'outlets', $filters, true ) ) {
			$outlets = get_posts(
				[
					'numberposts' => - 1,
					'post_type'   => 'pos_outlet',
				]
			);
			if ( $outlets ) {
				?>
		<select name='_outlet_id' id='_outlet_id'>
		<option value=""><?php esc_html_e( 'All outlets', 'woocommerce-point-of-sale' ); ?></option>
				<?php
				foreach ( $outlets as $outlet ) {
					echo '<option value="' . esc_attr( $outlet->ID ) . '" ' . selected( $req_out, $outlet->ID, false ) . ' >' . esc_html( $outlet->post_title ) . '</option>';
				}
				?>
		</select>
				<?php
			}
		}
	}

	public function add_order_metabox() {
		if ( ! $this->is_orders_page() ) {
			return;
		}

		global $post_id;

		$q_id  = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$id    = $post_id ?? $q_id;
		$id    = absint( $id );
		$order = wc_get_order( $id );

		if ( ! $order || 'pos' !== $order->get_created_via() ) {
			return;
		}

		$screen = wc_pos_custom_orders_table_usage_is_enabled() ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';

		add_meta_box(
			'wc-pos-order-metabox',
			__( 'Point of Sale', 'woocommerce-point-of-sale' ),
			[ $this, 'order_metabox_output' ],
			$screen,
			'side'
		);
	}

	public function order_metabox_output() {
		global $post_id;

		$q_id  = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$id    = $post_id ?? $q_id;
		$order = wc_get_order( $id );

		$register     = wc_pos_get_register( absint( $order->get_meta( 'wc_pos_register_id' ) ) );
		$cashier      = $order->get_meta( 'wc_pos_served_by_name' );
		$amount       = floatval( $order->get_meta( 'wc_pos_amount_pay' ) );
		$change       = floatval( $order->get_meta( 'wc_pos_amount_change' ) );
		$order_number = $order->get_meta( 'wc_pos_prefix_suffix_order_number' ); // @todo fix me.
		$signature    = $order->get_meta( 'wc_pos_signature' );
		$receipt      = wc_pos_build_order_receipt(
			$register ? $register->get_receipt() : (int) get_option( 'wc_pos_default_receipt' ),
			$order
		);
		?>
		<?php if ( $register ) : ?>
		<div class="row">
			<?php esc_html_e( 'Register', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo esc_html( $register->get_name() ); ?></strong></span>
		</div>
		<?php endif; ?>

		<div class="row">
		<?php esc_html_e( 'Cashier', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo esc_html( $cashier ); ?></strong></span>
		</div>

		<div class="row">
		<?php esc_html_e( 'Total', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong></span>
		</div>

		<?php if ( $amount > 0 ) : ?>
		<div class="row">
			<?php esc_html_e( 'Tendered', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo wp_kses_post( wc_price( $amount ) ); ?></strong></span>
		</div>
		<?php endif; ?>

		<?php if ( $change > 0 ) : ?>
		<div class="row">
			<?php esc_html_e( 'Change', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo wp_kses_post( wc_price( $change ) ); ?></strong></span>
		</div>
		<?php endif; ?>

		<?php if ( $change < 0 ) : ?>
		<div class="row amount_due">
			<?php esc_html_e( 'Amount Due', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo wp_kses_post( wc_price( $change ) ); ?></strong></span>
		</div>
		<?php endif; ?>

		<?php if ( $order_number ) : ?>
		<div class="row">
			<?php esc_html_e( 'Order Number', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo esc_html( $order_number ); ?></strong></span>
		</div>
		<?php endif; ?>

		<?php
		$coupons = wc_get_order( $id )->get_items( 'coupon' );
		$reason  = '';

		foreach ( $coupons as $coupon ) {
			// @todo fix me
			// Reasons no longer used. Coupon code is the reason.
			if ( 0 === strpos( $coupon->get_code(), 'pos_discount' ) ) {
				$reason = wc_get_order_item_meta( $coupon->get_id(), 'reason', true );
				break;
			}
		}
		?>

		<?php if ( ! empty( $reason ) ) : ?>
		<div class="row">
			<?php esc_html_e( 'Discount Reason', 'woocommerce-point-of-sale' ); ?> <span><strong><?php echo esc_html( $reason ); ?></strong></span>
		</div>

		<?php endif; ?>

		<?php if ( $signature ) : ?>
		<div id="thickbox-signature" style="display:none;">
			<div class="TB_container">
				<img
					src="data:image/png;base64,<?php echo esc_attr( str_replace( 'data:image/png;base64,', '', $signature ) ); ?>"
					alt="signature"
					id="signature-img"
					style="max-height:90%";
					/>
			</div>
		</div>

		<a
			href="#TB_inline?width=300&height=300&inlineId=thickbox-signature"
			class="thickbox button button-primary"
		>
			<?php esc_html_e( 'Signature', 'woocommerce-point-of-sale' ); ?>
		</a>
		<?php endif; ?>


		<div id="thickbox-receipt" style="display:none;">
			<?php if ( $receipt ) : ?>
			<div class="TB_actions">
				<button onClick="tb_remove();" class="button"><?php esc_html_e( 'Cancel', 'woocommerce-point-of-sale' ); ?></button>
				<button onClick="printReceipt();" id="print_receipt_button" class="button button-primary"><?php esc_html_e( 'Print', 'woocommerce-point-of-sale' ); ?></button>
			</div>

			<?php endif; ?>
			<div class="TB_container" style="background:#f5f5f5;">
				<?php if ( $receipt ) : ?>
				<script type="text/javascript">
					const container = window.document.querySelector('#thickbox-receipt .TB_container')

					if (container) {
						const receipt = document.createElement( 'app-receipt' );

						receipt.setAttribute('i18n', JSON.stringify(<?php echo wp_json_encode( $receipt['i18n'] ); ?>))
						receipt.setAttribute('data', JSON.stringify(<?php echo wp_json_encode( $receipt['data'] ); ?>))
						receipt.setAttribute('options', JSON.stringify(<?php echo wp_json_encode( $receipt['options'] ); ?>))
						receipt.setAttribute('type', 'order')

						container.prepend(receipt)
					}
				</script>
				<?php else : ?>
				<h2><?php esc_html_e( 'Receipt could not be generated. Please refresh the page and try again.', 'woocommerce-point-of-sale' ); ?></h2>
				<?php endif; ?>
			</div>
		</div>

		<a
			href="/?TB_inline?width=460&height=600&inlineId=thickbox-receipt"
			class="thickbox button button-primary"
		>
			<?php esc_html_e( 'Print Receipt', 'woocommerce-point-of-sale' ); ?>
		</a>
		<?php
	}
}

return new WC_POS_Admin_Orders_Page();
